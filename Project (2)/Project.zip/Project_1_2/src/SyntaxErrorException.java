//----------------------------------------------------------------------------------------------------//
// Contributers:-
// - Muhammed Enes Gökdeniz (150121538)
// - Tolga Fehmioğlu (150120022)
// - Abdelrahman Zahran (150120998)
//----------------------------------------------------------------------------------------------------//
/** SyntaxErrorException **/
public class SyntaxErrorException extends RuntimeException {
    public SyntaxErrorException(String message){
        super(message);
    }
}
//----------------------------------------------------------------------------------------------------//